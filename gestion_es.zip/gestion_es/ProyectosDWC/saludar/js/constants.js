const GREETING_ES = "Escriba su nombre ",
      GREETING_EN = "Give me your name ",
      SALUTE_EN = "Good afternoon ",
      SALUTE_ES = "Buenas tardes ";
