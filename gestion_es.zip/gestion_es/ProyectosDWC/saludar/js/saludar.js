

var name = window.prompt(GREETING_ES);
window.alert(SALUTE_ES + " " + name);
