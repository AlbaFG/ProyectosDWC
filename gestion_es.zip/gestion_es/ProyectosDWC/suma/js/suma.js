
var pideNumero = "Escribe un número";
var numero1;
var numero2;
var suma = numero1 + numero2;



numero1 = parseInt(window.prompt(pideNumero));
numero2 = parseInt(window.prompt(pideNumero));;
window.alert("El resultado es: " + suma);
